import { getArtifactsIndex, getArtifactsData } from '@/lib/content.server';
import FeedClient from './FeedClient';

export const dynamic = 'force-dynamic';

export default function FeedPage() {
  // Server-side data loading — reads latest data on every request
  const artifactsIndex = getArtifactsIndex();
  const artifactsData = getArtifactsData();

  // Compute department counts for the filter bar
  const deptCounts: Record<string, number> = { all: artifactsIndex.length };
  for (const a of artifactsIndex) {
    deptCounts[a.department] = (deptCounts[a.department] || 0) + 1;
  }

  // Compute A0-A9 phase counts (cross-department)
  const phaseCounts: Record<string, number> = {};
  for (const a of artifactsIndex) {
    const p = a.chain_phase;
    if (p) phaseCounts[p] = (phaseCounts[p] || 0) + 1;
  }

  // Compute A0-A9 phase counts from statistics (server-side aggregation)
  const aPhaseCounts = artifactsData.statistics.by_a_phase || {};
  const knowledgeCounts: Record<string, number> = {};
  for (const a of artifactsIndex) {
    if (a.department !== 'knowledge') continue;
    // tags are stored as space-separated string (from content.server.ts)
    const tags = typeof a.tags === 'string' ? a.tags.split(' ').filter(Boolean) : [];
    for (const t of tags) {
      knowledgeCounts[t] = (knowledgeCounts[t] || 0) + 1;
    }
  }

  return (
    <FeedClient
      artifacts={artifactsIndex}
      deptCounts={deptCounts}
      phaseCounts={phaseCounts}
      knowledgeCounts={knowledgeCounts}
      totalArtifacts={artifactsData.total}
    />
  );
}
