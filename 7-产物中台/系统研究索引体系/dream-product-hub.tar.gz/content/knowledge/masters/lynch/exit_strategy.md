# 彼得·林奇 - 离场智慧

**大师**: 彼得·林奇 (Peter Lynch)
**来源**: 《One Up on Wall Street》+ Fidelity Magellan Fund管理记录
**适用场景**: 成长股投资、基本面分析

---

## 💡 核心离场原则

### 1. 基本面恶化立即离场
> "当公司基本面发生根本性恶化时，不要留恋。"

**应用**:
- 监测关键指标：盈利增长、市场份额、行业地位
- 基本面恶化 = L0立即离场

**A9映射**: `L0_fundamental_deterioration` 规则

---

### 2. 估值过热分批离场
> "当PE超过盈利增长率2倍时，开始减仓。"

**应用**:
- PEG指标: PE / Earnings_Growth_Rate
- PEG > 2 → L1分批离场（30% → 30% → 40%）

**A9映射**: `L1_overvaluation_peg` 规则

---

### 3. 故事改变清仓离场
> "当投资逻辑（故事）不再成立时，果断离场。"

**应用**:
- 定期检查投资逻辑（每季度）
- 逻辑失效 = L0立即离场

**A9映射**: `L0_investment_thesis_broken` 规则

---

## 📊 离场规则清单

| 规则ID | 离场信号 | 触发条件 | A9层级 | 置信度 |
|--------|----------|----------|--------|--------|
| LYNCH_1 | 基本面恶化 | fundamental_deterioration | L0 | 0.95 |
| LYNCH_2 | 估值过热 | PEG > 2 | L1 | 0.85 |
| LYNCH_3 | 投资故事改变 | investment_thesis_broken | L0 | 0.90 |
| LYNCH_4 | 行业衰退 | industry_decline | L1 | 0.80 |
| LYNCH_5 | 管理层变更 | key_management_change | L2 | 0.70 |

---

## 🎯 A9决策树集成

```
IF fundamental_deterioration OR investment_thesis_broken:
    ACTION: L0_IMMEDIATE_EXIT
    REASON: "林奇基本面/故事改变原则"
    
IF PEG > 2 AND holding_months > 6:
    ACTION: L1_PARTIAL_EXIT (30%)
    REASON: "林奇估值过热原则"
    
IF industry_decline AND growth_slowdown:
    ACTION: L1_PARTIAL_EXIT (50%)
    REASON: "林奇行业衰退原则"
```

---

## 📚 历史案例

### 案例1: 1987年减持得州 Instruments
- **入场**: 1986年，看好半导体行业复苏
- **离场**: 1987年10月股灾前，识别估值过热
- **收益**: 约50%回报
- **离场依据**: PEG > 2.5 + 行业周期顶部

### 案例2: 1990年退休前清仓
- **入场**: 1977-1990年管理Magellan Fund
- **离场**: 1990年自愿退休，清仓所有持仓
- **收益**: 年化回报29%（13年）
- **离场依据**: 个人原因（非投资逻辑）

---

## ⚠️ 风险提示

1. **PEG局限性**: 成长股早期可能无盈利，PEG失效
2. **基本面滞后**: 财务数据每季度更新，可能错过最佳离场时机
3. **故事主观性**: 不同投资者对同一事件的解读可能不同

---

## 🔄 与加密货币结合

- **适配调整**: 加密项目无盈利，需用其他指标（TVL、用户增长）
- **成长股逻辑**: 适用于Layer1、DeFi新项目
- **估值指标**: 使用MVRV、NVT比率替代PEG

---

**最后更新**: 2026-05-01 08:30
**维护者**: A9离场决策部
**验证状态**: pending (等待A6联网搜索验证)
