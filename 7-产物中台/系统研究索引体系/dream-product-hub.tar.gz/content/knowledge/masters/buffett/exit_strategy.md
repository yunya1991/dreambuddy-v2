# 沃伦·巴菲特 - 离场智慧

**大师**: 沃伦·巴菲特 (Warren Buffett)
**来源**: 伯克希尔哈撒韦年会 + 股东信 + 历史交易记录
**适用场景**: 价值投资、长期持有

---

## 💡 核心离场原则

### 1. 企业基本面恶化
> "如果不想持有10年，就不要持有10分钟。"

**应用**:
- 监测企业基本面指标（ROE、自由现金流、护城河）
- 基本面恶化 = 立即离场信号

**A9映射**: `L0_fundamental_deterioration` 规则

---

### 2. 价格远超价值
> "别人贪婪时我恐惧。"

**应用**:
- 计算内在价值（DCF、PE、PB）
- 价格 > 内在价值 × 1.5 → 考虑离场

**A9映射**: `L1_overvaluation` 规则

---

### 3. 发现更好机会
> "机会成本是最重要的成本。"

**应用**:
- 比较现有持仓与潜在新机会
- 新机会预期收益 > 现有持仓20% → 轮换

**A9映射**: `L2_opportunity_cost` 规则

---

## 📊 离场规则清单

| 规则ID | 离场信号 | 触发条件 | A9层级 | 置信度 |
|--------|----------|----------|--------|--------|
| BUFFETT_1 | 基本面恶化 | fundamental_deterioration | L0 | 0.95 |
| BUFFETT_2 | 过度估值 | overvaluation > 50% | L1 | 0.85 |
| BUFFETT_3 | 机会成本 | better_opportunity_exist | L2 | 0.70 |
| BUFFETT_4 | 管理层诚信问题 | management_integrity_issue | L0 | 0.99 |
| BUFFETT_5 | 行业根本性变化 | industry_disruption | L1 | 0.80 |

---

## 🎯 A9决策树集成

```
IF fundamental_deterioration OR management_integrity_issue:
    ACTION: L0_IMMEDIATE_EXIT
    REASON: "巴菲特基本面/诚信原则"
    
IF overvaluation > 50% AND holding_years > 3:
    ACTION: L1_PARTIAL_EXIT (30%)
    REASON: "巴菲特过度估值原则"
    
IF better_opportunity_exist AND expected_return_diff > 20%:
    ACTION: L2_ROTATION
    REASON: "巴菲特机会成本原则"
```

---

## 📚 历史案例

### 案例1: 2007年减持中石油
- **入场**: 2003年，识别中石油低估
- **离场**: 2007年，价格远超内在价值
- **收益**: 约7倍回报
- **离场依据**: 过度估值 + 行业周期性顶部

### 案例2: 2012年增持IBM（后减持）
- **入场**: 2011年，看好IBM云转型
- **离场**: 2017年，转型不及预期
- **收益**: 小幅亏损
- **离场依据**: 基本面恶化（云业务竞争加剧）

---

## ⚠️ 风险提示

1. **估值主观性**: 内在价值计算依赖假设
2. **持有周期长**: 可能错过中期交易机会
3. **不适用于短线**: 仅适用于长期价值投资

---

## 🔄 与加密货币结合

- **适配调整**: 加密货币无现金流，需用其他估值方法（MVRV、NVT比率）
- **护城河概念**: 适用于Layer1项目（以太坊、Solana）
- **长期持有**: 适合比特币等"数字黄金"

---

**最后更新**: 2026-05-01 08:25
**维护者**: A9离场决策部
**验证状态**: pending (等待A6联网搜索验证)
