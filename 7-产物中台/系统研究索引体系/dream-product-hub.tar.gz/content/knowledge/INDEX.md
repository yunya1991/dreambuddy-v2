# 📚 知识库总索引 - 图书馆管理架构

**版本**: v2.0 (图书馆式分类索引)
**最后更新**: 2026-05-01 08:35
**维护者**: A6情报部 + 做梦部 + A9离场决策部

---

## 🏛️ 图书馆管理架构说明

本知识库采用**三层分类架构**（类似国家图书馆分类法）：

### Level 1: 按功能模块分类（A系列）
- `A0-A3`: 情报分析模块
- `A4`: 战术验证模块  
- `A5`: 战术执行模块
- `A6-A8`: 支持模块
- `A9`: 离场决策模块

### Level 2: 按知识类型分类
- `masters/`: 大师智慧库
- `risk_events/`: 风险事件库
- `exit_rules/`: 离场规则库
- `trading_tools/`: 交易工具库
- `online_search/`: 联网搜索结果库
- `practical/`: 实践经验库

### Level 3: 按具体条目分类
- 每个目录下按时间、品种、策略类型细分
- 使用YAML frontmatter统一管理元数据
- 支持全文检索和标签过滤

---

## 📊 知识库核心部分分类（A4 & A9）

### 🎯 A4 战术验证 - 三层索引体系

#### 第一层：策略索引（按优先级排序）
| 优先级 | 索引名称 | 状态 | 路径 | 条目数 |
|--------|----------|------|------|--------|
| 1 | 大师策略库 | ✅ | `knowledge/masters/*/summary.md` | 6 |
| 2 | **联网搜索库** | ✅ **(新创建)** | `knowledge/online_search/` | 0 |
| 3 | **实践经验库** | ✅ **(新创建)** | `knowledge/practical/` | 0 |

#### 第二层：工具索引
| 索引名称 | 状态 | 路径 | 工具数 |
|----------|------|------|--------|
| 交易工具库 | ✅ | `knowledge/trading_tools.yaml` | 15 |
| OKX命令库 | ❌ | `knowledge/okx_commands.yaml` | 0 |

#### 第三层：跨资产设计
| 索引名称 | 状态 | 路径 | 资产数 |
|----------|------|------|--------|
| 宏观资产库 | ❌ | `knowledge/macro_assets.yaml` | 0 |
| 币种相关库 | ❌ | `knowledge/symbol_correlation.yaml` | 0 |

---

### 🎯 A9 离场决策 - 四层决策链

#### 第0层：风险库静态检测
| 索引名称 | 状态 | 路径 | 事件数 |
|----------|------|------|--------|
| 风险事件库 | ✅ | `knowledge/risk_events.yaml` | 21 |

#### L0/L1/L2：离场规则库
| 索引名称 | 状态 | 路径 | 规则数 |
|----------|------|------|--------|
| 离场规则库 | ✅ | `knowledge/exit_rules.yaml` | 15 |

#### 大师离场智慧（新增）
| 大师名称 | 状态 | 路径 | 规则数 |
|----------|------|------|--------|
| 杰西·利弗莫尔 | ✅ **(新创建)** | `knowledge/masters/livermore/exit_strategy.md` | 5 |
| 斯坦利·德鲁肯米勒 | ✅ **(新创建)** | `knowledge/masters/druckenmiller/exit_strategy.md` | 5 |
| 沃伦·巴菲特 | ✅ **(新创建)** | `knowledge/masters/buffett/exit_strategy.md` | 5 |
| 彼得·林奇 | ✅ **(新创建)** | `knowledge/masters/lynch/exit_strategy.md` | 5 |
| 乔治·索罗斯 | ✅ **(新创建)** | `knowledge/masters/soros/exit_strategy.md` | 5 |
| 约翰·保尔森 | ✅ **(新创建)** | `knowledge/masters/paulson/exit_strategy.md` | 5 |

---

## 🔍 检索方式

### 1. 按A系列检索
- **A4相关**: `knowledge/masters/*`, `knowledge/online_search/`, `knowledge/practical/`, `knowledge/trading_tools.yaml`
- **A9相关**: `knowledge/risk_events.yaml`, `knowledge/exit_rules.yaml`, `knowledge/masters/*/exit_strategy.md`

### 2. 按资产类别检索
- **加密货币**: `knowledge/masters/*/summary.md`, `knowledge/online_search/crypto/`
- **宏观资产**: `knowledge/masters/*/summary.md` (黄金、原油、铜部分)

### 3. 按策略类型检索
- **趋势跟踪**: `knowledge/masters/livermore/`, `knowledge/trading_tools.yaml#trend_following`
- **均值回归**: `knowledge/masters/buffett/`, `knowledge/trading_tools.yaml#mean_reversion`
- **网格交易**: `knowledge/trading_tools.yaml#grid_trading`

### 4. 全文检索（未来集成Pagefind）
- 支持关键词搜索
- 支持标签过滤
- 支持时间范围筛选

---

## 📈 统计数据

### 知识库规模
- **总文件数**: 23个
- **总条目数**: 52条（策略/规则/事件）
- **总大师数**: 6位
- **YAML结构化数据**: 3个文件

### 完成度
- **A4三层索引**: 50% (3/6)
- **A9四层决策链**: 80% (4/5)
- **大师离场智慧**: 100% (6/6) ✅

---

## 🔄 自动更新规则

### 触发条件
1. **A4执行联网搜索后** → 更新 `online_search/`
2. **A5执行完成后** → 更新 `practical/`
3. **A6情报分析后** → 更新 `risk_events.yaml`
4. **A9离场决策后** → 更新 `exit_rules.yaml`

### 老化清理
- **30天**: 未验证的联网搜索结果自动归档
- **90天**: 未验证的实践案例自动归档
- **180天**: 历史风险事件转移到大宗祠

---

## 📁 目录结构总览

```
knowledge/
├── INDEX.md                          # 本文件 - 总索引
├── online_search/                    # ⭐ 新创建 - A4第一层索引
│   └── INDEX.md
├── practical/                        # ⭐ 新创建 - A4第一层索引
│   └── INDEX.md
├── risk_events.yaml                 # A9第0层 - 风险事件库
├── exit_rules.yaml                  # A9 L0/L1/L2 - 离场规则库
├── trading_tools.yaml               # A4第二层 - 交易工具库
└── masters/
    ├── livermore/
    │   ├── summary.md               # 大师资料
    │   └── exit_strategy.md        # ⭐ 新创建 - 离场智慧
    ├── druckenmiller/
    │   ├── summary.md
    │   └── exit_strategy.md        # ⭐ 新创建
    ├── buffett/
    │   ├── summary.md
    │   └── exit_strategy.md        # ⭐ 新创建
    ├── lynch/
    │   ├── summary.md
    │   └── exit_strategy.md        # ⭐ 新创建
    ├── soros/
    │   ├── summary.md
    │   └── exit_strategy.md        # ⭐ 新创建
    └── paulson/
        ├── summary.md
        └── exit_strategy.md        # ⭐ 新创建
```

---

**最后更新**: 2026-05-01 08:35
**下一步**: 更新 `artifacts_index.json` 添加新产物
