# 实践经验库 - 索引

**用途**: A4战术验证第一层索引（第三优先级/兜底）
**更新频率**: 每次交易实践后更新
**数据来源**: A5执行记录 + A7实践论 + A8复盘

---

## 📚 分类架构（图书馆式）

### Level 1: 按实践结果分类
- `successful/` - 成功案例（盈利 > 2%）
- `failed/` - 失败案例（亏损 > 2%）
- `break_even/` - 盈亏平衡案例

### Level 2: 按策略类型分类
- `trend_following/` - 趋势跟踪实践
- `grid/` - 网格实践
- `martingale/` - 马丁实践
- `dca/` - 定投实践
- `short/` - 做空实践

### Level 3: 按市场环境分类
- `bull_market/` - 牛市
- `bear_market/` - 熊市
- `sideways/` - 震荡市
- `high_volatility/` - 高波动

---

## 📝 实践案例条目模板

```yaml
- id: "practice_YYYYMMDD_HHMMSS"
  link_artifacts:
    - "A5_执行明细_YYYYMMDD_HHMMSS.md"
    - "A7_实践论复盘_YYYYMMDD_HHMMSS.md"
  strategy_type: "trend_following"
  asset: "BTC-USDT-SWAP"
  regime: "trending"
  entry_price: 65000.0
  exit_price: 72000.0
  profit_loss: 10.5  # 百分比
  execution_score: 85  # A7实践论评分
  key_lessons: |
    1. 趋势确认后再入场，避免假突破
    2. 移动止损设置合理，保护利润
    3. 仓位管理得当，未过度杠杆
  validation_status: "verified"  # verified/unverified
  created_at: "2026-05-01T08:30:00+08:00"
  tags: ["BTC", "trend", "success", "A7_verified"]
```

---

## 📊 现有实践案例

*(暂无记录，等待首次实践)*

---

## 🔄 自动更新规则

1. **触发条件**: A5执行完成 + A7实践论复盘完成
2. **更新方式**: 追加新案例到对应分类文件
3. **验证机制**: A7实践论评分 > 70 标记为 verified
4. **老化清理**: 90天前的unverified案例自动归档

---

## 🎯 使用场景

- **A4战术验证**: 第一层索引第三优先级（大师策略 → 联网搜索 → **实践经验**）
- **策略优化**: 根据历史实践调整策略参数
- **风险警示**: 失败案例提供风险教训

---

## 📈 统计数据（自动生成）

*(将在首次实践后生成)*

- 总案例数: 0
- 成功率: 0%
- 平均收益: 0%
- 最佳策略: 暂无
- 最差策略: 暂无

---

**最后更新**: 2026-05-01 08:25
**维护者**: A5战术执行部 + A7实践论部
