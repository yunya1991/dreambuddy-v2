# 联网搜索结果库 - 索引

**用途**: A4战术验证第一层索引（第二优先级）
**更新频率**: 每次联网搜索后自动更新
**数据来源**: Tavily/ Odaily / 网络搜索结果

---

## 📚 分类架构（图书馆式）

### Level 1: 按资产类别分类
- `crypto/` - 加密货币策略
- `macro/` - 宏观资产策略（黄金、原油、铜）
- `equity/` - 股票策略

### Level 2: 按策略类型分类
- `trend_following/` - 趋势跟踪
- `mean_reversion/` - 均值回归
- `breakout/` - 突破策略
- `grid/` - 网格策略
- `scalping/` - 剥头皮策略

### Level 3: 按时间框架分类
- `short_term/` - 短期（1-7天）
- `medium_term/` - 中期（1-4周）
- `long_term/` - 长期（1月+）

---

## 🔍 搜索结果条目模板

```yaml
- id: "search_YYYYMMDD_HHMMSS"
  search_query: "BTC trend following strategy 2026"
  source: "tavily"
  url: "https://..."
  title: "Bitcoin Trend Following in 2026"
  summary: "核心观点摘要..."
  strategy_type: "trend_following"
  asset_class: "crypto"
  timeframe: "medium_term"
  confidence: 0.75
  validation_status: "pending"  # pending/validated/rejected
  created_at: "2026-05-01T08:30:00+08:00"
  tags: ["BTC", "trend", "2026"]
```

---

## 📊 现有搜索结果

*(暂无记录，等待首次搜索)*

---

## 🔄 自动更新规则

1. **触发条件**: A4执行联网搜索后
2. **更新方式**: 追加新条目到对应分类文件
3. **去重机制**: 检查URL和标题相似性，避免重复
4. **老化清理**: 30天未验证的pending条目自动归档

---

## 🎯 使用场景

- **A4战术验证**: 第一层索引第二优先级（大师策略 → **联网搜索** → 实践经验）
- **策略匹配**: 根据A3推演情景，搜索相似策略
- **验证参考**: 为A4验证方案提供外部证据

---

**最后更新**: 2026-05-01 08:25
**维护者**: A6情报部 + 做梦部
